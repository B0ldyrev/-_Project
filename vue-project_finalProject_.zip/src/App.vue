<script setup>
  import { ref, computed } from 'vue'

  const header = ref('Список задач')
  const CharacterCount = computed(() => {
    return NewToDo.value.length
  })
  const todolist = ref([ 
 {
  id: 1, 
  label: "Просмотреть обучающий курс", 
  tasked: true,
  checkbox: false
  },

 {
  id: 2, 
  label: "Выполнить поставленные задачи ", 
  tasked: true,
  checkbox: false,
  },

{id: 3, 
label: "Сдать работу", 
tasked: false,
checkbox:true 
}
  ])

  const NewToDo = ref("")
  const NewTodoCheckBox = ref(false)
  const SaveToDo =()=>{
    todolist.value.push({
     id: todolist.value.length + 1,
     label: NewToDo.value,
     tasked: NewTodoCheckBox.value
    })

        NewToDo.value=""
        NewTodoCheckBox.value = "";  

  }
  const editing = ref(false)
  const doEdit = (e)=>{
    editing.value = e
    NewToDo.value = ""
     NewTodoCheckBox.value = "";   

  }

  const toggleTasked = (todo) => {
    todo.tasked =!todo.tasked
  } 
</script>

<template>
  <div class="main-menu" :class="{ 'doEdit(true)': editing }">

      <h1>{{ header }}</h1>
        <div class="line"></div> <!--отрисовка линии-->
            <div class="home">
              <div class="home-buttons">
               <template v-if="editing">
        <button class="cancel" @click="doEdit(false)">Венруться</button>
    </template>
    <template v-else>
        <button class="add" @click="doEdit(true)">Добавить задачу</button>
    </template>
              </div>
            </div>
    <form 
          v-if="editing"
          @submit.prevent="SaveToDo" 
          class="blocks"> <!--Контейнер разделяющий список с полем ввода-->
      <div class="list">
        <ul>
          <li
           v-for="(todo, index) in todolist" 
           @click="toggleTasked(todo)"
           :key="todo.id"
           class="static-class"
           :class="{strikeout: todo.tasked,
           priority: todo.tasked
                   }"
          >
          {{ todo.label }}

          </li>
          
        </ul>
        <p v-if="!todolist.length">Ваш список задач пуст</p>


      </div>
      <div class="input">
        <input 
        v-model.trim="NewToDo" 
        type="text">
        <button class="btn-Ok"
                v-bind:disabled="NewToDo.length === 0" >ok</button> <!-- обращение к классу todolist по типу id (увеличение размера +1), label  -->
          <p class="counter">
            {{ CharacterCount }}/200
          </p>
        <div class="check"> <!--Повышенный приоритет-->
          <label>
          <input type="checkbox" v-model="NewTodoCheckBox">
          Повышенный приоритет
          </label>
        </div>
       
      </div>

    </form>

  </div>
</template>